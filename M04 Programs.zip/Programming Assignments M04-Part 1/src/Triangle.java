/*
Program Name: The triangle finder
Author: Michael Krause
Last Update: 10/13/2021
Purpose: To use the parent class GeometricObject with the child class Triangle to find the perimeter and area of a triangle entered by the user. 
*/

import java.util.Scanner;

//Triangle class as an extension of GeometricObject class (Inheritance)
public class Triangle extends GeometricObject {
	
	//Attributes of class
    private double side1 = 1.0;
    private double side2 = 1.0;
    private double side3 = 1.0;
    
    //Default triangle constructor
    Triangle() {

    }
    
    //Create new object with user entry
    Triangle(double side1, double side2, double side3) {
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }
    
    //Accessors
    public double getSide1() {
    	return side1;
    }
    public double getSide2() {
    	return side2;
    }
    public double getSide3() {
    	return side3;
    }
     
    //Mutators
    public void setSide1(double side1) {
    	this.side1 = side1;
    }
    public void setSide2(double side2) {
    	this.side2 = side2;
    }
    public void setSide3(double side3) {
    	this.side3 = side3;
    }
    
    //Methods
    public double getArea() {
    	//Find s first
    	double s = (getSide1() + getSide2() + getSide3()) / 2.0;
        //Find Area
    	return Math.pow(s * (s - getSide1()) * (s - getSide2()) * (s - getSide3()), 0.5);
    }	
    public double getPerimeter() {
        return getSide1() + getSide2() + getSide3();
    }
    
    //toString override to print sides of the triangle
    public String toString() {
        return "Triangle: side1 = " + getSide1() + " side2 = " + getSide2() + " side3 = " + getSide3();
    }
    //
    //Main
    //
    public static void main(String[] args) {
    	
    	//Initialize variables for the triangle and scanner
    	double side1, side2, side3;
    	String color;
    	Scanner input = new Scanner(System.in);
    	
    	//Prompt user with message for triangle
    	System.out.println("Enter the three sides of the triangle, in any order.");
        side1 = input.nextDouble();
        side2 = input.nextDouble();
        side3 = input.nextDouble();
        
        //Prompt User for the triangles color
        System.out.println("What color is the triangle?");
        color = input.next();
        
        //Prompt user for boolean value
        System.out.println("\nIs the triangle filled? (true or false)");
        boolean filled = input.nextBoolean();
        
        //Create new triangle object from user input
        Triangle userTriangle = new Triangle(side1, side2, side3);
        
        //Use methods from parent class to set the color and the fill status
        userTriangle.setColor(color);
        userTriangle.setFilled(filled);
        
        //Display the triangle area, perimeter, sides, color, and bool
        //Use the methods from this class and the methods from the GeometricObject
        System.out.println("\n" + userTriangle.toString());
        System.out.println("Perimeter: " + userTriangle.getPerimeter());
        System.out.println("Area: " + userTriangle.getArea());
        System.out.println("Triangles color: " + userTriangle.getColor());
        System.out.println("The triangle is filled: " + userTriangle.isFilled());
    }  
}

/*
Class named Triangle
Triangle extends to GeometricObject
Contains 3 doubles fields side1, side2, side3 default 1.0
no-arg constructor create default triangle
constructor for user specified triangle
Accessor methods for all three data fields 
getArea() 
//UML diagram link
https://lucid.app/lucidchart/56b55ac4-7ddf-42e2-a684-90849c5a49b2/edit?viewport_loc=-47%2C37%2C2620%2C1261%2CHWEp-vi-RSFO&invitationId=inv_07e2db3b-95a0-40f0-9743-047193500b58 
getPerimeter()  
toString() : "Triangle: side1 = " + side1 + " side2 = " + side3;
Write a test program
Ask user to enter three sides of triangle
Ask to enter a color
Ask to enter a Boolean value to indicate whether the triangle is filled
Create object
Print object
Display area, perimeter, sides, color, true or false
*/
