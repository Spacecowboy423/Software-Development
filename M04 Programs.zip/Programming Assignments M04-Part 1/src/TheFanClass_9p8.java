/*
Project Name: The Digital Fan
Author: Michael Krause
Last Update: 10/13/2021
Purpose: To create a class called fan that simulates a real fan. Alter the attribute within the class, then print the results back to the user
*/

public class TheFanClass_9p8 {
	
	//Attributes of Fan Class
	static final int SLOW = 1;
	static final int MEDIUM = 2;
	static final int FAST = 3;
	private int Speed;
	private boolean On;
	private double Radius;
	private String Color;
	
	//Constructor (creates default Fan object)
	public TheFanClass_9p8(){
		Speed = SLOW;
		On = false;
		Radius = 5.0;
		Color = "Blue";
	}
	
	//Accessors (Get Methods)
	public int GetSpeed() {
		return Speed;
	}
	public double GetRadius() {
		return Radius;
	}
	public String GetColor() {
		return Color;
	}
	public boolean GetStatus() {
		return On;
	}
	
	//Mutators (Set Methods)
	public void SetSpeed(int Speed) {
		this.Speed = Speed;
	}
	public void SetRadius(double Radius) {
		this.Radius = Radius;
	}
	public void SetColor(String Color) {
		this.Color = Color;
	}
	public void SetStatus(boolean On) {
		this.On = On;
	}
	
	//toString method to return each object
	public String toString(){
		//Check if Fan is on or off
		if(GetStatus()){
			return "Fan Status: Fan is on\n" + "Fan Speed: " + GetSpeed() + "\n" + "Fan Color: " + GetColor() + "\n" + "Fan Radius: " + GetRadius() + "\n";
		}
		else{
			return "Fan Status: Fan is off\n" + "Fan Color: " + GetColor() + "\n" + "Fan Radius: " + GetRadius() + "\n";
		}
	}
	//
	//Main
	//
	public static void main(String[] args) {
		
		//Create Fan number 1
		TheFanClass_9p8 fan1 = new TheFanClass_9p8();
		
		//Change all default settings
		fan1.SetSpeed(TheFanClass_9p8.FAST);
		fan1.SetRadius(10);
		fan1.SetColor("Yellow");
		fan1.SetStatus(true);
		
		//Print fan 1
		System.out.println(fan1.toString());
		
		//Create Fan number 2 with default settings
		TheFanClass_9p8 fan2 = new TheFanClass_9p8();
		
		//Change speed of Fan 2 from default
		fan2.SetSpeed(TheFanClass_9p8.MEDIUM);
		
		//Print fan 2
		System.out.println(fan2.toString());
	}
}

/*
Design a class Fan
Three constants named SLOW, MEDIUM, FAST with valued 1, 2, 3
private int data field named speed
private boolean data field named on
private double data field named radius
String data field named color
Accessors and Mutator methods for all 4
a no-arg constructor to default fan
toString()
https://lucid.app/lucidchart/ff97dc76-7fc2-4455-ae92-5dcd954b81cc/edit?beaconFlowId=D2B2EB027A428267&invitationId=inv_5b67bd10-8258-4cbc-8205-5af82f84f54f&page=HWEp-vi-RSFO#
*/
