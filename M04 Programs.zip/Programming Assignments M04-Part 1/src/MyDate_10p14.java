/*
Project Name: Calender Sim
Author: Michael Krause
Last Update: 10/23/2021
Purpose: To find the current date using the Gregorian Calender. Then find the time that has passed since 1970 jan 1 to a specified time. 
*/

import java.util.GregorianCalendar;
import java.util.Calendar;

public class MyDate_10p14{
	
	//Attributes
	private int Year;
	private int Month;
	private int Day;
	
	//No-arg constructor of MyDate object with current date
	public MyDate_10p14(){
		GregorianCalendar current = new GregorianCalendar();// Today's date
		this.Year = current.get(Calendar.YEAR);
		this.Month = current.get(Calendar.MONTH) + 1;
		this.Day = current.get(Calendar.DAY_OF_MONTH);
	}
	
	//Constructor of MyDate object to find date from elapsed time since midnight, January 1, 1970 in milliseconds
	public MyDate_10p14(long elapsedTime1970) {
		GregorianCalendar since1970 = new GregorianCalendar();
        since1970.setTimeInMillis(elapsedTime1970);
        this.Year = since1970.get(Calendar.YEAR);
        this.Month = since1970.get(Calendar.MONTH);
        this.Day = since1970.get(Calendar.DAY_OF_MONTH);
	}
	
	//Constructor of MyDate object with a specified year, month, and day
	public MyDate_10p14(int Day, int Month, int Year) {
		this.Year = Year;
		this.Month = Month;
		this.Day = Day;
	}
	
	//Accessors (Get Methods)
	public int GetYear() {
		return Year;
	}
	public int GetMonth() {
		return Month;
	}
	public int GetDay() {
		return Day;
	}
	
	//Mutators (Set Methods)
	public void SetDay(int Day) {
		this.Day = Day;
	}
	public void SetMonth(int Month) {
		this.Month = Month;
	}
	public void SetYear(int Year) {
		this.Year = Year;
	}
	
	//Method sets a new date for the object using the elapsed time
	public void SetDate(long elapsedTime) {
		GregorianCalendar user = new GregorianCalendar();
	    user.setTimeInMillis(elapsedTime);
	    Year = user.get(Calendar.YEAR);
	    Month = user.get(Calendar.MONTH);
	    Day = user.get(Calendar.DAY_OF_MONTH);
	}
	
	//toString method
	public String toString() {
		return "Date from object:\nYear: " + GetYear() + "\nMonth: " + GetMonth() + "\nDay: " + GetDay();
	}
	//
	//Main
	//
	public static void main(String[] args) {
		//Create two MyDate objects
		//First object is new MyDate()
		MyDate_10p14 Current = new MyDate_10p14();
		
		//Second object is new MyDate(34355555133101L)
		MyDate_10p14 since1970 = new MyDate_10p14(34355555133101L);
		
		//Print year, month, day of each object
		System.out.println("\nDate from elapsed time in milliseconds since 1970:\n" + since1970.toString());
		System.out.println("\nCurrent date:\n" + Current.toString());
		
	}
}

/*
Create class MyDate
Contain: year, month, day
A no-arg constructor that creates a MyDate object for the current date
Aconstructor that constructs a MyDate object with a specified elapsed time since midnight, January 1, 1970, in milliseconds
A constructor that constructs a MyDate object with a specified year, month, and day
Accessors:
3 methods for the data fields:
year
month
day
Mutators:
3 methods for the data fields:
year
month
day
A method named setDate(long elapsedTime) that sets a new date for the object using the elapsed time
Draw a UML diagram for the class then implement the class
Test program that creates two MyDate objects (using new MyDate() and new MyDate(34355555133101L) and display their year, month, and day
(first two constructors with extract year, month, and day from elapsed time)
*/