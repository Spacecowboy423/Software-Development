/*
Program Name: Additions Quiz
Author: Michael Krause
Last Updated: 12/12/2021
Purpose: Write a JSP program that generates addition quizzes randomly. 
After the user answers all questions, the JSP displays the result.
*/

import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped

public class AdditionQuiz {
	// Fields
	private int Size = 10;
	private List<Numbers> Numbers = new ArrayList<Numbers>();
	private int Count = 0;

	// Method calls renew method
	public AdditionQuiz() {
		renew();
	}

	// Method clears and fills with new random number
	public void renew() {
		Numbers.clear();
		for (int i = 0; i < Size; i++) {
			Numbers.add(new Numbers());
		}
		Count = 0;
	}

	// Accessors
	public List<Numbers> getNumbers() {
		return Numbers;
	}

	public int getCount() {
		return Count;
	}

	public int getSize() {
		return Size;
	}

	// Mutator
	public void resetCount() {
		Count = 0;
	}

	// Numbers class ///////
	public class Numbers {
		private int Number1;
		private int Number2;
		private int Total;
		private String UserInput = "";

		public Numbers() {
			Number1 = (int) (Math.random() * 20);
			Number2 = (int) (Math.random() * 20);
			Total = Number1 + Number2;
		}

		// Parameterized Constructor
		public Numbers(int Number1, int Number2) {
			this.Number1 = Number1;
			this.Number2 = Number2;
			Total = Number1 + Number2;
		}

		// Accessors
		public int getNumber1() {
			return Number1;
		}

		public int getNumber2() {
			return Number2;
		}

		public int getTotal() {
			return Total;
		}

		public String getUserInput() {
			return UserInput;
		}

		// Mutators
		public void setNumber1(int Number1) {
			this.Number1 = Number1;
			Total = Number1 + Number2;
		}

		public void setNumber2(int Number2) {
			this.Number2 = Number2;
			Total = Number1 + Number2;
		}

		public void setUserInput(String UserInput) {
			this.UserInput = UserInput;
		}

		// Method validates which user inputs were right or wrong, or not valid
		public String validate() {
			try {
				if (Integer.parseInt(UserInput) == Total) {
					Count++;
					return "Correct";
				} else {
					return "Wrong";
				}
			}

			catch (NumberFormatException e) {
				return "Wrong";
			}
		}
	}
}