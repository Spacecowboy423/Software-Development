/*
Program Name:
Author: Michael Krause
Last Update: 12/12/2021
Purpose: To create a program that views, inserts, and updates staff 
information stored in a database.
*/

// Imports
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
//
//
//
public class StaffTable extends JApplet {
	// Fields
	private static final long serialVersionUID = 1L;
	private JTextField TextField1 = new JTextField(10);
	private JTextField TextField2 = new JTextField(10);
	private JTextField TextField3 = new JTextField(10);
	private JTextField TextField4 = new JTextField(3);
	private JTextField TextField5 = new JTextField(10);
	private JTextField TextField6 = new JTextField(10);
	private JTextField TextField7 = new JTextField(3);
	private JTextField TextField8 = new JTextField(10);
	private JTextField TextField9 = new JTextField(10);
	// For connecting to database
	private Connection connection;
	
	// Initial stage scene 
	public void init() {
		// Create new borderlayout
		setLayout(new BorderLayout());
		// Initialize Database
		initializeDB();

		// Textfields and Labels
		JPanel Panel1 = new JPanel(new FlowLayout());
		Panel1.setBorder(new TitledBorder("Staff information"));
		Panel1.add(new JLabel("ID"));
		Panel1.add(TextField1);
		Panel1.add(new JLabel("Last Name"));
		Panel1.add(TextField2);
		Panel1.add(new JLabel("First Name"));
		Panel1.add(TextField3);
		Panel1.add(new JLabel("MI"));
		Panel1.add(TextField4);
		Panel1.add(new JLabel("Address"));
		Panel1.add(TextField5);
		Panel1.add(new JLabel("City"));
		Panel1.add(TextField6);
		Panel1.add(new JLabel("State"));
		Panel1.add(TextField7);
		Panel1.add(new JLabel("Telephone"));
		Panel1.add(TextField8);
		Panel1.add(new JLabel("E-mail"));
		Panel1.add(TextField9);
		add(Panel1, BorderLayout.CENTER);

		// Buttons
		JPanel Panel2 = new JPanel(new GridLayout(1, 4, 5, 5));
		Panel2.setBorder(new EmptyBorder(5, 5, 5, 5));
		JButton Button1 = new JButton("View");
		Panel2.add(Button1);
		JButton Button2 = new JButton("Insert");
		Panel2.add(Button2);
		JButton Button3 = new JButton("Update");
		Panel2.add(Button3);
		JButton Button4 = new JButton("Clear");
		Panel2.add(Button4);
		add(Panel2, BorderLayout.SOUTH);

		// When Select is pressed
		Button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String queryString = "Select LastName, FirstName, MI, Address, City, State, Telephone, Email, ID;";
				try {
					PreparedStatement preparedStatement = connection.prepareStatement(queryString);
					preparedStatement.setString(1, TextField1.getText());
					ResultSet rset = preparedStatement.executeQuery();
					
					if (rset.next()) {
						TextField1.setText(rset.getString(1));
						TextField2.setText(rset.getString(2));
						TextField3.setText(rset.getString(3));
						TextField4.setText(rset.getString(4));
						TextField5.setText(rset.getString(5));
						TextField6.setText(rset.getString(6));
						TextField7.setText(rset.getString(7));
						TextField8.setText(rset.getString(8));
						TextField9.setText(rset.getString(9));
					} 
					
					else {
						TextField1.setText("");
						TextField2.setText("");
						TextField3.setText("");
						TextField4.setText("");
						TextField5.setText("");
						TextField6.setText("");
						TextField7.setText("");
						TextField8.setText("");
						TextField9.setText("");
					}
				} 
				
				catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});

		// When Insert is pressed
		Button2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String queryString = "Insert Staff, ID, LastName, FirstName, MI, Address, City, State, Telephone, Email;";
				
				try {
					PreparedStatement preparedStatement = connection.prepareStatement(queryString);
					preparedStatement.setString(1, TextField1.getText());
					preparedStatement.setString(2, TextField2.getText());
					preparedStatement.setString(3, TextField3.getText());
					preparedStatement.setString(4, TextField4.getText());
					preparedStatement.setString(5, TextField5.getText());
					preparedStatement.setString(6, TextField6.getText());
					preparedStatement.setString(7, TextField7.getText());
					preparedStatement.setString(8, TextField8.getText());
					preparedStatement.setString(9, TextField9.getText());
					preparedStatement.executeUpdate();
				} 
				
				catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});

		// When Update staff is pressed
		Button3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String queryString = "Update Staff: Set LastName, FirstNam, MI, Address, City, State, Telephone, Email, ID";
			
				try {
					PreparedStatement preparedStatement = connection.prepareStatement(queryString);
					preparedStatement.setString(1, TextField1.getText());
					preparedStatement.setString(2, TextField2.getText());
					preparedStatement.setString(3, TextField3.getText());
					preparedStatement.setString(4, TextField4.getText());
					preparedStatement.setString(5, TextField5.getText());
					preparedStatement.setString(6, TextField6.getText());
					preparedStatement.setString(7, TextField7.getText());
					preparedStatement.setString(8, TextField8.getText());
					preparedStatement.setString(9, TextField9.getText());
					preparedStatement.executeUpdate();
				} 
				
				catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});

		// When Create staff is pressed
		Button4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Statement statement = connection.createStatement();
					statement.executeUpdate("Delete Staff Member;");
					TextField1.setText("");
					TextField2.setText("");
					TextField3.setText("");
					TextField4.setText("");
					TextField5.setText("");
					TextField6.setText("");
					TextField7.setText("");
					TextField8.setText("");
					TextField9.setText("");
				} 
				
				catch (SQLException e2) {
					e2.printStackTrace();
				}
			}
		});
	}
	
	// Database
	private void initializeDB() {
		try {
			// Load the JDBC driver
			Class.forName("com.mysql.jdbc.Driver");
			// Establish Connection
			connection = DriverManager.getConnection("jdbc:mysql://localhost/javabook", "scott", "tiger");
		} 
		
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	//
	// Main
	//
	public static void main(String[] args) {
		StaffTable Table = new StaffTable();
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Extra Exercise 34_01");
		frame.getContentPane().add(Table, BorderLayout.CENTER);
		Table.init();
		Table.start();
		frame.setSize(540, 200);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}
