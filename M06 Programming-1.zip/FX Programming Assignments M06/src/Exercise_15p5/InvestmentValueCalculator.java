/*
Program Name: Investment Calculator
Author: Michael Krause
Last Update: 11/16/2021
Purpose: Calculates the future value of an investment at a given interest rate for a specified number of years.
*/
package Exercise_15p5;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.geometry.HPos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class InvestmentValueCalculator extends Application {
	private TextField tfInvestment = new TextField();
	private TextField tfYears = new TextField();
	private TextField tfRate = new TextField();
	private TextField tfFuture = new TextField();
	private Button btCalculate = new Button("Calculate");

	@Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
      // Create UI
      GridPane gridPane = new GridPane();
      gridPane.setHgap(5);
      gridPane.setVgap(5);
      gridPane.add(new Label("Amount Invested:"), 0, 0);
      gridPane.add(tfInvestment, 1, 0);
      gridPane.add(new Label("Years Invested:"), 0, 1);
      gridPane.add(tfYears, 1, 1);
      gridPane.add(new Label("Interest Rate:"), 0, 2);
      gridPane.add(tfRate, 1, 2);
      gridPane.add(new Label("Future Value:"), 0, 3);
      gridPane.add(tfFuture, 1, 3);
      gridPane.add(btCalculate, 1, 5);

      // Set properties for UI
      gridPane.setAlignment(Pos.CENTER);
      tfInvestment.setAlignment(Pos.BOTTOM_RIGHT);
      tfYears.setAlignment(Pos.BOTTOM_RIGHT);
      tfRate.setAlignment(Pos.BOTTOM_RIGHT);
      tfFuture.setAlignment(Pos.BOTTOM_RIGHT);
      tfFuture.setDisable(true);
      GridPane.setHalignment(btCalculate, HPos.RIGHT);

      // Process events
      btCalculate.setOnAction(e -> FutureValue());

      // Create a scene and place it in the stage
      Scene scene = new Scene(gridPane, 400, 250);
      primaryStage.setTitle("Futures Calculator"); // Set title
      primaryStage.setScene(scene); // Place the scene in the stage
      primaryStage.show(); // Display the stage
    }

	private void FutureValue() {
		// Get values from text fields
		double Investment = Double.parseDouble(tfInvestment.getText());
		double Years = Double.parseDouble(tfYears.getText());
		double Interest = Double.parseDouble(tfRate.getText()) / 12 / 100;
		double Future = Investment * Math.pow(1 + Interest, Years * 12);
		tfFuture.setText(String.format("$%.2f", Future));// set text to calculated value
	}
    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
    */
    public static void main(String[] args){
    	Application.launch(args);
    }
}
