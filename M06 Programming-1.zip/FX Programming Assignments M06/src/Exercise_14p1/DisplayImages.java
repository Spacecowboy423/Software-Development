/*
Program Name: Display Images
Author: Michael Krause
Last Update: 11/15/2021
Purpose: To take in the image files and display them back in a grid pane
*/
package Exercise_14p1;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class DisplayImages extends Application {

	@Override
	public void start(Stage primaryStage) {

		// Create a gride pane for the images
		GridPane pane = new GridPane();

		// Place each node in the grid
		pane.add(new ImageView(new Image("uk.gif")), 0, 0);
		pane.add(new ImageView(new Image("ca.gif")), 1, 0);
		pane.add(new ImageView(new Image("china.gif")), 0, 1);
		pane.add(new ImageView(new Image("us.gif")), 1, 1);

		// Create the scene and place it within the stage
		Scene scene = new Scene(pane);
		// Give the stage a title
		primaryStage.setTitle("The Big Show");
		// Sets the scene for our stage 
		primaryStage.setScene(scene);
		// Displays the scene 
		primaryStage.show();
	}
	// Main
	public static void main(String[] args) {
		// Launch the application with our scene
		Application.launch(args);
	}
}