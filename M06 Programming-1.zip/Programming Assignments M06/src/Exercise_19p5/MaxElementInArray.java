package Exercise_19p5;

import java.util.Scanner;

public class MaxElementInArray {
	// Method to find max number from array
	public static <E extends Comparable<E>> E max(E[] list) {
		// Set new "E" equal to first element in array to begin comparing
		E MaxNumber = list[0];
		for (int i = 0; i < list.length; ++i) {
			// Compares list number to max number and returns 1 or 0 (true or false)
			if (list[i].compareTo(MaxNumber) > 0) {
				MaxNumber = list[i];
			}
		}
		return MaxNumber;
	}
	//
	// Main
	//
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		// Prompt User
		System.out.println("Enter 10 integers, seperated by a space or enter after each number:");
		// Initialize array with Integer wrapper
		Integer arr[] = new Integer[10];
		// Store values in array
		for (int i = 0; i < arr.length; ++i) {
			arr[i] = input.nextInt();
		}
		// Print output
		System.out.println("The max number is " + max(arr));
		input.close();
	}
}