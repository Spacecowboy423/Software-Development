/*
Project Name: Mega-Power-Lotto!
Programmer: Michael Krause
Last Update: 9/1/2021
Purpose: To take in a 3 digit number from the user and compare it to a randomly 
generated 3 digit number. Then display results of the comparison to the user.  
*/

package chapter3_problems;
import java.util.Scanner;
	public class Problem_3point15 {
		public static void main(String[] args) {
			//Generate 3 digit Lottery number
			int Lottery = (int) ((Math.random() * 1000));
			//Validation loop to keep generating a number until it is a 3 digit number
			while (Lottery < 100 || Lottery > 999) {
				Lottery = (int) (Math.random() * 1000);
			}
			
			Scanner input = new Scanner(System.in);
			
			//Prompt the user to enter a 3 digit number to guess
			System.out.println("Welcome to the three digit lottery! Enter a three digit number and see if you win!? (Ex: 175)");
			//Validate User input
			int guess = input.nextInt();
			while (guess < 100 || guess > 999) {
				System.out.println("Number must be a 3 digits. (Ex: between 100 and 999)");
				guess = input.nextInt();
			}
			//Close the input scanner
			input.close();
			
			//Find the three digits from Lottery number
			int Lottery1 = (Lottery / 100);
			int Lottery2 = (Lottery % 100) / 10;
			int Lottery3 = (Lottery % 10);
			
			//Find the three digits from the users guess
			int guess1 = (guess / 100);
			int guess2 = (guess % 100) / 10;
			int guess3 = (guess % 10);
			
			//Check for Jackpot winner
			if (Lottery == guess) {
				System.out.println("Congratulations! You won the grand Jackpot of $10,000 for matching the number exactly!");
				System.out.println("Your number: " + guess + ".");
				System.out.println("Lottery number: " + Lottery + ".");
			}
			//Check if all guessed digits match to Lottery digits 
			else if ((guess1 == Lottery1 || guess1 == Lottery2 || guess1 == Lottery3) && (guess2 == Lottery1  || guess2 == Lottery2 || guess2 == Lottery3) && (guess3 == Lottery1 || guess3 == Lottery2 || guess3 == Lottery3)) {
				System.out.println("Congrats! You won the runner up prize of $3,000 for matching all the digits to the Lottery number! Just not in the right order.");
				System.out.println("Your number: " + guess + ".");
				System.out.println("Lottery number: " + Lottery + ".");
			}
			//Check if a single guessed digit matches the Lottery digits
			else if ((guess1 == Lottery1 || guess1 == Lottery2 || guess1 == Lottery3) || (guess2 == Lottery1 || guess2 == Lottery2 || guess2 == Lottery3) || (guess3 == Lottery1 || guess3 == Lottery2 || guess3 == Lottery3)) {
				System.out.println("Congrats! You have successfully guessed one of the digits in the Lottery number and won $1,000!");
				System.out.println("Your number: " + guess + ".");
				System.out.println("Lottery number: " + Lottery + ".");
			}
			//If no numbers match
			else
				System.out.println("Too bad, it's just not your day. You haven't won anything but you can play again anytime.");
				System.out.println("Your number: " + guess + ".");
				System.out.println("Lottery number: " + Lottery + ".");
		
	}

}
