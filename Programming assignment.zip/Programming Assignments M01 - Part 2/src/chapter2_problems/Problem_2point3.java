/*
Project Name: The Converter
Programmer: Michael Krause
Last Update: 9/1/2021
Purpose: To take in an integer for feet and convert it to meters
*/

package chapter2_problems;
import java.util.Scanner;

public class Problem_2point3 {
	public static void main (String[] args) {
		Scanner input = new Scanner(System.in);
		
		//Prompt user for data
		System.out.println("Enter a value for feet:");
		
		//Gather data from user
		double feet = input.nextDouble();
		
		//Close the input scanner
		input.close();
		
		//Convert feet to meter
		double meters = feet * 0.305;
		
		/*
		Just for fun I made sure the output would always be positive even if you entered a 
		negative instead of using a validation loop to force the user to enter a positive number.
		*/
		System.out.println(Math.abs(feet) + " feet converts to " + Math.abs(meters) + " meters.");
		
	}
}

