/*
Project Name: Math!
Programmer: Michael Krause
Last Update: 9/1/2021
Purpose: Evaluate an expression and print the results
*/

package chapter1_problems;
	public class Problem_1point5 {
		public static void main (String[] args) {
			
			//Prompt user with the expression
			System.out.println("Expression:\n(9.5 X 4.5) - (2.5 X 3)\n-----------------------\n      45.5 - 3.5");
			
			//Calculate the expression and output the data to user
			System.out.println("\nAnswer:\n" + (9.5 * 4.5 - 2.5 * 3)/(45.5 - 3.5));
		}
	}

