/*
Program Name: Split That File
Author: Michael Krause
Last Update: 12/01/2021
Purpose: To take in a user specified text file and split it according to the users choice. Then output the split files back to the user.
All with a gui interface for the user.
*/

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.*;

public class SplitFiles extends Application {

	private class MainScene extends BorderPane {
		// TextFields and Buttons For Scene
		TextField tfUserFile;
		TextField tfSplits;
		Button btSplit;
		
		// Scene Constructor
		MainScene() {
			// TextFields
			tfUserFile = new TextField();
			tfSplits = new TextField();
			
			// Buttons
			btSplit = new Button("Split File");
			btSplit.setOnAction(e -> FileSplitter());
			
			// Labels for seperate
			Label Main = new Label("If you split a file named temp.txt into 3 smaller files,\n"
				+ "the three smaller files are temp.txt.1, temp.txt.2, temp.txt.3.\n");
			Label UserFile = new Label("Enter a file:");
			Label NumberOfSplits = new Label("Specify the number of smaller files:");	
			
			// Create new GridPane and set Labels and Buttons
			GridPane layout = new GridPane();
			layout.add(Main, 0, 0, 2, 1);
			layout.addRow(1, UserFile, tfUserFile);
			layout.addRow(2, NumberOfSplits, tfSplits);
			layout.setHgap(5);
			layout.setVgap(5);
			layout.setPadding(new Insets(10));
			setCenter(layout);
			setBottom(btSplit);
			setAlignment(btSplit, Pos.CENTER);
			setPadding(new Insets(5));
		}
		
		// Method to split the file
		private void FileSplitter() {
			
			// Create copy of original file
			File UserFile = new File(tfUserFile.getText());
			
			// Convert textfields to data values
			int NumberOfSplits = Integer.parseInt(tfSplits.getText());
			long NewFileLength = UserFile.length() / NumberOfSplits + 1;
			
			// Exception Handling for the Input Stream, BufferedInputStream transfers the data by Byte information and more methods to use
			try (BufferedInputStream InputFile = new BufferedInputStream(new FileInputStream(UserFile))) {
				// Loop runs the number of files to split
				for (int i = 1; i <= NumberOfSplits; i++) {
					// Reset variable after each file  
					int InputLength = 0;
					// Exception Handling for the Output Stream
					// absolute grabs the original file to then increment the save file by 1
					try (BufferedOutputStream OutputFile = new BufferedOutputStream(new FileOutputStream(new File(UserFile.getAbsoluteFile() + "." + i)))) {
						// Variable is used to transfer data to output file
						int temp;
							// Output to new file
							while (InputLength++ < NewFileLength && (temp = InputFile.read()) != -1) {
								// Buffered method writes the byte information into the output stream and into the file	
								OutputFile.write(temp);
							}
						}
					}
				} 
			
			// Handle errors
			catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	//
	//Start
	//
	@Override
	public void start(Stage primaryStage) {
		MainScene pane = new MainScene();
		primaryStage.setScene(new Scene(pane));
		primaryStage.setTitle("Let's Split Some Files");
		primaryStage.show();
	}
	//
	//Main
	//
	public static void main(String[] args) {
		Application.launch(args);
	}
}