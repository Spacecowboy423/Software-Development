/*
Program Name: Parallel Sum
Author: Michael Krause
Last Update: 12/11/2021
Purpose: Program fills a double array with 9000000 random numbers (so I don't have to) and returns the sum value back to the user
using the recursivetask to and forkjoin methods to split the array into 2 halfs, find the sum of each half, then rejoin the halves to 
get the total sum of the 9000000 numbers in the array.
*/

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

public class ParallelSum {
	
	// Class to extend recursive task for doubles
	private static class SumTask extends RecursiveTask<Double> {
		private static final long serialVersionUID = 1L;
		private final static int THRESHOLD = 1000;
		private double[] array;
		private int low;
		private int high;
		
		// Method to set the private values of the class
		public SumTask(double[] array, int low, int high) {
			this.array = array;
			this.low = low;
			this.high = high;
		}

		@Override
		protected Double compute() {
			// If values from array are less than 1000 the array will be added sequentially
			if (high - low < THRESHOLD) {
				double sum = 0;
				for (int i = low; i < high; i++) {
					sum += array[i];
				}
				return sum;
			} 
			// If values from array exceed 1000 it is more effecient to use recursive task and fork to split array, 
			// adding both halves seperately before rejoining (adding in this case) both halves to get the total
			else {
				int mid = (low + high) / 2;
				RecursiveTask<Double> left = new SumTask(array, low, mid);
				RecursiveTask<Double> right = new SumTask(array, mid, high);

				right.fork();
				left.fork();
				return left.join() + right.join();
			}
		}
	}
	
	// Function using recursivetask and forkjoinpool to invoke compute and return the sum of the two halves upon completing the main task
	public static double parallelSum(double[] array) {
		RecursiveTask<Double> mainTask = new SumTask(array, 0, array.length);
		ForkJoinPool pool = new ForkJoinPool();  
		return pool.invoke(mainTask); 
	}
	//
	// Main
	//
	public static void main(String[] args) {
		// Instantiate array of doubles to hold 9000000 numbers then fill is with random numbers
		double[] array = new double[9000000];
		for (int i = 0; i < array.length; i++) {
			array[i] = Math.random();
		}
		System.out.print(parallelSum(array));
	}
}
