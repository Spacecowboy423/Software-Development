/*
Project Name: The Stateside Shuffle
Author: Michael Krause
Last Updated: 12/01/2021
Purpose: To randomaly generate a different question each turn. The goal is to ask the user for the capital to a state.
*/

import java.util.*;

public class GuessingCapitals {
	// Dynamic Array of States and Capitals
	private static String[][] StatesAndCapitals = { 
		{ "Alabama", "Montgomery" }, { "Alaska", "Juneau" }, { "Arizona", "Phoenix" }, { "Arkansas", "Little Rock" }, 
		{ "California", "Sacramento" }, { "Colorado", "Denver" }, { "Connecticut", "Hartford" }, { "Delaware", "Dover" },
		{ "Florida", "Tallahassee" }, { "Georgia", "Atlanta" }, { "Hawaii", "Honolulu" }, { "Idaho", "Boise" },
		{ "Illinois", "Springfield" }, { "Maryland", "Annapolis" }, { "Minnesota", "Saint Paul" }, { "Iowa", "Des Moines" }, 
		{ "Maine", "Augusta" }, { "Kentucky", "Frankfort" }, { "Indiana", "Indianapolis" }, { "Kansas", "Topeka" }, 
		{ "Louisiana", "Baton Rouge" }, { "Oregon", "Salem" }, { "Oklahoma", "Oklahoma City" }, { "Ohio", "Columbus" },
		{ "North Dakota", "Bismark" }, { "New York", "Albany" }, { "New Mexico", "Santa Fe" }, { "New Jersey", "Trenton" }, 
		{ "New Hampshire", "Concord" }, { "Nevada", "Carson City" }, { "Nebraska", "Lincoln" }, { "Montana", "Helena" }, 
		{ "North Carolina", "Raleigh" }, { "Missouri", "Jefferson City" }, { "Mississippi", "Jackson" }, { "Massachusetts", "Boston" },
		{ "Michigan", "Lansing" }, { "Pennsylvania", "Harrisburg" }, { "Rhode Island", "Providence" }, { "South Carolina", "Columbia" }, 
		{ "South Dakota", "Pierre" }, { "Tennessee", "Nashville" }, { "Texas", "Austin" }, { "Utah", "Salt Lake City" }, { "Vermont", "Montpelier" },
		{ "Virginia", "Richmond" }, { "Washington", "Olympia" }, { "West Virginia", "Charleston" }, { "Wisconsin", "Madison" }, { "Wyoming", "Cheyenne" } 
	};
	//
	//Main
	//
	public static void main(String[] args) {
		// List will act as the key value
		LinkedList<String[]> list = new LinkedList<>();
		// Store everything in a collection (similar to a map)
		Collections.addAll(list, StatesAndCapitals);
		// For user input
		Scanner input = new Scanner(System.in);
		
		// Count correct number of answers
		int Count = 0;
		// Run until end of list (all 50 states)
		while (list.size() > 0) {
			// Use collections method to shuffle list each iteration
			Collections.shuffle(list);
			// Grab first item in list after shuffle .pollfirst also removes it from the list
			String[] States = list.pollFirst();
			// Display question with the random state
			System.out.print("What is the capital of " + States[0] + "?\n");
			
			// Display confirmation and add 1 to count
			if (input.nextLine().equalsIgnoreCase(States[1])) {
				System.out.println("That's Right!\n");
				Count++;
			} 
			// Display correct capital, the next item currently in the array
			else {
				System.out.println("The correct answer is: " + States[1] + "\n");
			}
		}
		// Display number of correct answers and close scanner input
		System.out.println("Questions you answered correctly: " + Count);
		input.close();
	}
}
