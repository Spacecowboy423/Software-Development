/*
Project Name: Turning 'Rationals' into 'BigRationals' 
Author: Michael Krause
Last Update: 11/2/2021
Purpose: To redesign the 'Rational' class using 'BigInteger'. Create a test program to allow user to input two rational numbers
and perform simple arithmetic. Display the results back to user.
*/
package Excercise_13p15;

import java.math.BigInteger;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    	// Prompt the user to enter the First Rational
        Scanner input = new Scanner(System.in);
        System.out.print("Enter rational number1 with numerator and denominator seperated by a space: ");
        String numerator1 = input.next();
        String denominator1 = input.next();
        //Prompt the user to enter the Second Rational
        System.out.print("Enter rational number2 with numerator and denominator seperated by a space: ");
        String numerator2 = input.next();
        String denominator2 = input.next();
        //Close input stream
        input.close();
        //Initialize each rational
        BigRational rational1 = new BigRational(new BigInteger(numerator1), new BigInteger(denominator1));
        BigRational rational2 = new BigRational(new BigInteger(numerator2), new BigInteger(denominator2));
        //Perform simple arithmetic and display results with simplified form (prints simplest form even if it's already in it)
        System.out.println("Addition:\n" + rational1 + " + " + rational2 + " = " + rational1.add(rational2));
        System.out.println("The simplified form of " + rational1.add(rational2) + " is: " + rational1.gcd(rational2, 1));
        System.out.println("Subtraction:\n" + rational1 + " - " + rational2 + " = " + rational1.subtract(rational2));
        System.out.println("The simplified form of " + rational1.subtract(rational2) + " is: " + rational1.gcd(rational2, 2));
        System.out.println("Multiplication:\n" + rational1 + " * " + rational2 + " = " + rational1.multiply(rational2));
        System.out.println("The simplified form of " + rational1.multiply(rational2) + " is: " + rational1.gcd(rational2, 3));
        System.out.println("Division:\n" + rational1 + " / " + rational2 + " = " + rational1.divide(rational2));
        System.out.println("The simplified form of " + rational1.divide(rational2) + " is: " + rational1.gcd(rational2, 4));
        System.out.println("Double Value:\n" + rational2 + " is " + rational2.doubleValue());
    }
}