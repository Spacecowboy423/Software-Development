package Excercise_13p15;
import java.math.BigInteger;

@SuppressWarnings("serial")
public class BigRational extends Number implements Comparable<BigRational> {
    // Data fields for numerator and denominator
    private BigInteger numerator;
    private BigInteger denominator;

    /** Construct a rational with default properties */
    public BigRational() {
        this(BigInteger.ZERO, BigInteger.ONE);
    }

    /** Construct a rational with specified numerator and denominator */
    public BigRational(BigInteger numerator, BigInteger denominator) {
    	 if (denominator.compareTo(BigInteger.ZERO) > 0) /*checks if denominator is larger than 0*/{
             this.numerator = numerator;
             this.denominator = denominator;
         } 
    	 else if (denominator.compareTo(BigInteger.ZERO) < 0) /*checks if denominator is negative*/{
             numerator = numerator.negate();
             denominator = denominator.negate();
             this.numerator = numerator;
             this.denominator = denominator;
         }
    }
    //Remade this to make finding the simplified form automatic
    //Find GCD of two Big Integer Rationals, divide the numerator and denominator by the GCD to create the simplified result
    BigRational gcd(BigRational secondBigRational, int a) {
    	switch (a) {
    	case (1):
    		BigInteger n1 = numerator.multiply(secondBigRational.getDenominator());
        	BigInteger n2 = denominator.multiply(secondBigRational.getNumerator());
        	BigInteger n = n1.add(n2);
        	BigInteger d = denominator.multiply(secondBigRational.getDenominator());
        	BigInteger gcd = n.gcd(d);
        	n = n.divide(gcd);
        	d = d.divide(gcd);
        	return new BigRational(n, d);
		case (2):
    		n1 = numerator.multiply(secondBigRational.getDenominator());
        	n2 = denominator.multiply(secondBigRational.getNumerator());
        	n = n1.subtract(n2);
        	d = denominator.multiply(secondBigRational.getDenominator());
        	gcd = n.gcd(d);
        	n = n.divide(gcd);
        	d = d.divide(gcd);
        	return new BigRational(n, d);
		case (3):
            n = numerator.multiply(secondBigRational.getNumerator());
            d = denominator.multiply(secondBigRational.getDenominator());
            gcd = n.gcd(d);
            n = n.divide(gcd);
            d = d.divide(gcd);
            return new BigRational(n, d);
		case (4):
            n = numerator.multiply(secondBigRational.getDenominator());
            d = denominator.multiply(secondBigRational.numerator);
            gcd = n.gcd(d);
            n = n.divide(gcd);
            d = d.divide(gcd);
            return new BigRational(n, d);
    	}
    	return new BigRational(numerator, secondBigRational.getDenominator());
    }
    /** Find GCD of two numbers */
    /*
    private static BigInteger gcd(BigInteger numerator, BigInteger denominator) {
    	BigInteger n1 = numerator.abs();
        BigInteger n2 = denominator.abs();

        BigInteger remainder = n1.remainder(n2);
        while (remainder.compareTo(BigInteger.ZERO) > 0) {
            n1 = n2;
            n2 = remainder;
            remainder = n1.remainder(n2);
        }
        return n2;
    }
    
    */
    
    /** Return numerator */
    public BigInteger getNumerator() {
        return numerator;
    }

    /** Return denominator */
    public BigInteger getDenominator() {
        return denominator;
    }

    /** Add a rational number to this rational */
    public BigRational add(BigRational secondBigRational) {
        BigInteger n1 = numerator.multiply(secondBigRational.getDenominator());
        BigInteger n2 = denominator.multiply(secondBigRational.getNumerator());
        BigInteger n = n1.add(n2);
        BigInteger d = denominator.multiply(secondBigRational.getDenominator());
        return new BigRational(n, d);
    }

    /** Subtract a rational number from this rational */
    public BigRational subtract(BigRational secondBigRational) {
    	BigInteger n1 = numerator.multiply(secondBigRational.getDenominator());
        BigInteger n2 = denominator.multiply(secondBigRational.getNumerator());
        BigInteger n = n1.subtract(n2);
        BigInteger d = denominator.multiply(secondBigRational.getDenominator());
        return new BigRational(n, d);
    }

    /** Multiply a rational number to this rational */
    public BigRational multiply(BigRational secondBigRational) {
        BigInteger n = numerator.multiply(secondBigRational.getNumerator());
        BigInteger d = denominator.multiply(secondBigRational.getDenominator());
        return new BigRational(n, d);
    }

    /** Divide a rational number from this rational */
    public BigRational divide(BigRational secondBigRational) {
        BigInteger n = numerator.multiply(secondBigRational.getDenominator());
        BigInteger d = denominator.multiply(secondBigRational.numerator);
        return new BigRational(n, d);
    }

    @Override
    public String toString() {
        if (denominator.equals(BigInteger.ONE))
            return numerator + "";
       else
            return numerator + "/" + denominator;
    }

    @Override // Override the equals method in the Object class
    public boolean equals(Object other) {
        if ((this.subtract((BigRational)(other))).getNumerator().equals(BigInteger.ZERO))
            return true;
        else
            return false;
    }

    @Override // Implement the abstract intValue method in Number
    public int intValue() {
        return (int)doubleValue();
    }

    @Override // Implement the abstract floatValue method in Number
    public float floatValue() {
        return (float)doubleValue();
    }

    @Override // Implement the doubleValue method in Number
    public double doubleValue() {
    	return numerator.doubleValue() / denominator.doubleValue();
    	//return numerator.divide(denominator).doubleValue();
    }

    public BigInteger bigIntegerDouble() {
        return numerator.divide(denominator);
    }

    @Override // Implement the abstract longValue method in Number
    public long longValue() {
        return (long)doubleValue();
    }

    @Override // Implement the compareTo method in Comparable
    public int compareTo(BigRational o) {
        if (this.subtract(o).getNumerator().compareTo(BigInteger.ZERO) > 0)
            return 1;
        else if (this.subtract(o).getNumerator().compareTo(BigInteger.ZERO) < 0)
            return -1;
        else
            return 0;
    }
}