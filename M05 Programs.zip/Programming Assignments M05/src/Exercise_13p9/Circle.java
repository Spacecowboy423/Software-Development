package Exercise_13p9;

class Circle extends GeometricObject {
    //Private Data Fields
	private double radius;
	//Default Constructor
    public Circle() {
    }
    //Parameterized Constructor
    public Circle(double radius) {
        this.radius = radius;
    }
    //Parameterized Constructor with base class methods
    public Circle(double radius, String color, boolean filled) {
        this.radius = radius;
        setColor(color);
        setFilled(filled);
    }
    /** Return radius */
    @Override
    public double getRadius() {
        return radius;
    }
    /** Set a new radius */
    public void setRadius(double radius) {
        this.radius = radius;
    }
    /** Return area */
    @Override
    public double getArea() {
        return radius * radius * Math.PI;
    }
    /** Return diameter */
    @Override
    public double getDiameter() {
        return 2 * radius;
    }
    /** Return perimeter */
    public double getPerimeter() {
        return 2 * radius * Math.PI;
    }
    /* Print the circle info */
    public void printCircle() {
        System.out.println("The circle is created " + getDateCreated() + " and the radius is " + radius);
    }
    //Override equals function by taking in an object and comparing the radius to current object radius and return bool
    @Override
    public boolean equals(GeometricObject obj) {
    	return obj instanceof Circle && radius == ((Circle) obj).radius;
    }
}