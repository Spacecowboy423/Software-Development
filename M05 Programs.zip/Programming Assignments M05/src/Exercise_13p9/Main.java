/*
Project Name: Inheritance, implementing Comparable 
Author: Michael Krause
Last Update: 11/1/2021
Purpose: To rewrite the 'Circle' class and extend 'GeometricObject' while implementing 'Comparable' interface. 
Override the 'equals' method in the 'Object' class. Compare circle objects together using their radii to know if they are the same.
*/
package Exercise_13p9;

public class Main {
	public static void main(String[] args) {
		//Instatiate each circle 
        Circle circle1 = new Circle(10);
        Circle circle2 = new Circle(10);
        Circle circle3 = new Circle(7);
        Circle circle4 = new Circle(7);
        //
        //I got a little redudant with my testing, trying some different things and I left them in
        //
        //Compare everything to circle 1
        System.out.println("Does Circle 1 equal Circle 2: " + circle1.equals(circle2));
        System.out.println("Does Circle 1 equal Circle 3: " + circle1.equals(circle3));
        System.out.println("Does Circle 1 equal Circle 4: " + circle1.equals(circle4));
        //Compare everything to circle 2
        System.out.println("\nDoes Circle 2 equal Circle 1: " + circle2.equals(circle1));
        System.out.println("Does Circle 2 equal Circle 3: " + circle2.equals(circle3));
        System.out.println("Does Circle 2 equal Circle 4: " + circle2.equals(circle4));
        //Compare everyhing to circle 3
        System.out.println("\nDoes Circle 3 equal Circle 1: " + circle3.equals(circle1));
        System.out.println("Does Circle 3 equal Circle 2: " + circle3.equals(circle2));
        System.out.println("Does Circle 3 equal Circle 4: " + circle3.equals(circle4));
        //Compare everything to circle 4
        System.out.println("\nDoes Circle 4 equal Circle 1: " + circle4.equals(circle1));
        System.out.println("Does Circle 4 equal Circle 2: " + circle4.equals(circle2));
        System.out.println("Does Circle 4 equal Circle 3: " + circle4.equals(circle3));
        //Print radius of each circle
        System.out.println("\nRadius of Circle 1: " + circle1.getRadius());
        System.out.println("Radius of Circle 2: " + circle2.getRadius());
        System.out.println("Radius of Circle 3: " + circle3.getRadius());
        System.out.println("Radius of Circle 4: " + circle4.getRadius());
        //Print area of each circle
        System.out.println("\nArea of Circle 1: " + circle1.getArea());
        System.out.println("Area of Circle 2: " + circle2.getArea());
        System.out.println("Area of Circle 3: " + circle3.getArea());
        System.out.println("Area of Circle 4: " + circle4.getArea());
        //Print diameter of each circle
        System.out.println("\nDiameter of Circle 1: " + circle1.getDiameter());
        System.out.println("Diameter of Circle 2: " + circle2.getDiameter());
        System.out.println("Diameter of Circle 3: " + circle3.getDiameter());
        System.out.println("Diameter of Circle 4: " + circle4.getDiameter());
        //Print perimeter of each circle
        System.out.println("\nPerimeter of Circle 1: " + circle1.getPerimeter());
        System.out.println("Perimeter of Circle 2: " + circle2.getPerimeter());
        System.out.println("Perimeter of Circle 3: " + circle3.getPerimeter());
        System.out.println("Perimeter of Circle 4: " + circle4.getPerimeter());
        
    }
}
