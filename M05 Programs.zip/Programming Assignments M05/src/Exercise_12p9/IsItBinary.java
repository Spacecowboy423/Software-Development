/*
Project Name: Is it binary!? 
Author: Michael Krause
Last Update: 10/30/2021
Purpose: To create a custom exception "BinaryFormatException" and use the bin2Dec method to find
if any entry is a binary number or not and to use the custom exception to handle cases where it
is not a binary number.
*/
package Exercise_12p9;

import java.util.Scanner;

public class IsItBinary {
	//Custom Exception handling class using java.lang.IllegalArgumentException->NumberFormatException
	@SuppressWarnings("serial")
	public static class BinaryFormatException extends NumberFormatException {
        //Default Constructor
		public BinaryFormatException() {
        }
		//Parameterized Constructor
        public BinaryFormatException(String s) {
            super(s);
        }
    }
	//bin2Dec method to convert string binary to string decimal
    public static int bin2Dec(String binaryString) throws BinaryFormatException {
        int total = 0;
        //Find length of string and check each character is '1' or '0'
        for(int i = 0; i < binaryString.length(); ++i) {
        	//stop loop and handle an exception
        	if(binaryString.charAt(i) != '0' && binaryString.charAt(i) != '1') {
                throw new BinaryFormatException(binaryString + " is not a binary String");
            }
        	//converts the binary char to it's decimal value, adds it to total
            total += Math.pow(2, binaryString.length() - i - 1) * (binaryString.charAt(i) - '0');
        }
        //return decimal value
        return total;
    }

    public static void main(String[] args) {
    	String x = "y";
    	//Gather user input
        Scanner input = new Scanner(System.in);
        //While loop to continue until user ends
        while (x.equalsIgnoreCase("y")) {
        	//Prompt User
        	System.out.print("Enter a binary number: ");
        	String UserString = input.nextLine();
        	//Check user entry and print appropriate response
        	try {
        		System.out.println("Decimal value of " + UserString + " is " + bin2Dec(UserString));
        	} 
        	catch (BinaryFormatException err) {
        		//getMessage is from java.lang//I just added the . and tried it out
        		System.out.println(err.getMessage());
        		//Otherwise I was using this one
        		//System.out.println(err);
        	}
        	//Check is user wants to enter another number
        	System.out.println("\nDo you want to try again? (y/n)");
        	x = input.nextLine();
        }
        //Close input stream when done
        input.close();
    }
}
