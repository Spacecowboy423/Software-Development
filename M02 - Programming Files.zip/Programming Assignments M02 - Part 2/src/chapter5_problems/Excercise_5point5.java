/*
Project Name: Convertable
Author: Michael Krause
Last Update: 9/15/2021
Purpose: To create a conversion table from kilo to lbs and vice versa
*/
package chapter5_problems;
public class Excercise_5point5 {
//Functions for program
//Convert From Kilo to Pounds
static double KtoP(int kilo) {
	double pounds = kilo * 2.2;
	return pounds;
}
//Convert From Pounds to Kilo
static double PtoK(int pounds) {
	double kilo = pounds/2.2;
	return kilo;
}
//
//Main 
//
	public static void main(String[] args) {
		//Declare and initialize variables
		int kilogram = 1;
		int pounds = 20;
		//Print out table with specified spacing
		System.out.println(String.format("%1s %12s %5s %10s %15s", "Kilograms", "Pounds", "|", "Pounds", "Kilograms"));
		//loop to print out until the end of the table
		while (kilogram < 200){
			//Print out table
			System.out.printf(kilogram + "\t\t" + String.format("%.1f", KtoP(kilogram)) + "\t   |\t " + pounds + "\t      "+ String.format("%.2f", PtoK(pounds)) + "\n");
			//Increases Kilogram and pounds each iteration
			kilogram = kilogram + 2;
			pounds = pounds + 5;
		}
	}
}
