/*
Project Name: *Sigh* Taxes
Author: Michael Krause
Last Update: 9/15/2021
Purpose: To take in an "employee" work information, perform the correct calculations and output the data
*/
package chapter4_problems;
import java.util.Scanner;
public class Excercise_4point23 {
//Methods
//Find Gross Pay
static double GrossPay(double rate, double hours) {
	double x = rate * hours;
	return x;
}
//Find Federal Withholding
static double FederalTax(double gross, double fed) {
	double tax = gross * fed;
	return tax;
}
//Find State Withholding
static double StateTax(double gross, double state) {
	double x = gross * state;
	return x;
}
//Find Net Pay
static double NetPay(double gross, double fed, double state) {
	double x = gross - (fed + state);
	return x;
}
//
//Main
//
	public static void main(String[] args) {
		//Scanner for input
		Scanner input = new Scanner(System.in);
		
		//Gather all data points
		System.out.println("Enter employee's name: ");
		String name = input.nextLine(); 
		System.out.println("Enter number of hours worked in a week: ");
		double hours = input.nextDouble();
		System.out.println("Enter the hourly pay rate: ");
		double rate = input.nextDouble();
		System.out.println("Enter the federal tax withholding rate: ");
		double fed = input.nextDouble();
		System.out.println("Enter state tax withholding rate: ");
		double state = input.nextDouble();
		//Close Scanner
		input.close();
		
		//Find values from entry
		double gross = GrossPay(rate, hours);
		double fedhold = FederalTax(gross, fed);
		double statehold = StateTax(gross, state);
		double net = NetPay(gross, fedhold, statehold);
		
		//Display data to correct decimal place 
		System.out.println("Employee Name: " + name);
		System.out.println("Hours Worked: " + hours);
		System.out.println("Pay Rate: $" + rate);
		System.out.println("Gross Pay: $" + String.format("%.2f", gross));
		System.out.println("Deductions:");
		System.out.println("\tFederal Withholding (" + (fed*100) + "%): $" + String.format("%.2f", fedhold));
		System.out.println("\tState Withholding (" + (state*100) + "%): $" + String.format("%.2f", statehold));
		System.out.println("\tTotal Deduction: $" + String.format("%.2f", (fedhold + statehold)));
		System.out.println("Net Pay: $" + String.format("%.2f", net));
	}
}
