/*
Project Name: Geometry!
Author: Michael Krause
Last Update: 9/15/2021
Purpose: To find the Area of a Pentagon and display the results
*/
package chapter4_problems;
import java.util.Scanner;
public class Excercise_4point1 {
//Boolean for validation loop
static Boolean bool = false;	
//Validate side length input	
static double ValidateLength() {
	//Prompt user with program description
	System.out.println("This program will find the area of a pentagon.\n");
	//Prompt user for input
	System.out.println("Enter the length from the center to a vertex.");
	Scanner input = new Scanner(System.in);
	double x = input.nextDouble();
	//If entry is negative or 0 the user will be prompt for re-entry
	while (bool == false) {
		if (x > 0) {
			bool = true;
		}
		if (bool == false) {
			System.out.println("Invalid Entry. The length of the side must be greater than 0.");
			x = input.nextDouble();
		}
	}
	//Close input before returning to program
	input.close();
	return x;
}
//Calculate the Side of the Pentagon
static double FindSide(double r) {
	double s = ((2*r)*(Math.sin(Math.PI/5)));
	return s;
}
//Calculate the Area of the Pentagon
static double FindArea(double s) {
	double A = ((5 * Math.pow(s,2))/(4 * Math.tan(Math.PI/5)) );
	return A;
}	
//
//Main
//
	public static void main(String[] args) {
		//Gather User Input using the function to validate input
	    double length = ValidateLength();
	    //Find Side using return function
	    double side = FindSide(length);
	    //Find Area using return function
	    double area = FindArea(side);
	    //Print out data
	    System.out.println("\nThe length from the center to a vertex: " + String.format("%.2f", length));
	    System.out.println("The length of a side: " + String.format("%.2f", side));
	    System.out.println("The Area of the pentagon: " + String.format("%.2f", area));
	}
}

