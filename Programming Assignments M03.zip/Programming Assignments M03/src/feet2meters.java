/*
 Project Name: Convertable for feet
 Author: Michael Krause
 Last Update: 9/16/2021
 Purpose: To convert feet to meters and vice versa using methods. Then display the data in a table. 
 */
public class feet2meters {
	//Method to convert from feet to meters
	public static double footToMeter (double foot) {
		double meter = 0.305 * foot;
		return meter;
	}
	//Method to convert from meters to feet
	public static double meterToFoot (double meter) {
		double foot = 3.279 * meter;
		return foot;
	}
	//
	//Main
	//
	public static void main (String[] args) {
		//Declare and initialize variables
		double Feet = 1;
		double Meters = 20;
		//Print out table with specified spacing
		System.out.println(String.format("%1s %12s %5s %10s %15s", "Feet", "Meters", "|", "Meters", "Feet"));
		//loop to print out until the end of the table
			while (Feet < 11){
				//Print out table
				System.out.printf(Feet + "\t   " + String.format("%.3f", footToMeter(Feet)) + "      |\t    " + Meters + "\t      "+ String.format("%.3f", meterToFoot(Meters)) + "\n");
				//Increases feet and meters each iteration
				Feet = Feet + 1;
				Meters = Meters + 5;
			}
	}
}