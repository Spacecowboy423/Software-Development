/*
Project Name: Compare Two 2-D Arrays
Author: Michael Krause
Last Update: 9/29/2021
Purpose: I think this style of input looks better. So I included it with the other assignments. 
 */

import java.util.Scanner;

public class TwoDArray {
	//Method to find if the two arrays are identical or not and return a boolean value
	public static boolean equals (int m1 [][], int m2 [][]) {
		//As long as both arrays are equal to each other in length it will run
		if (m1.length == m2.length) {
			//Sets i equal to the length of m1
			for(int i = 0; i < m1.length; i++) {
				//Set j equal to the length of m2
				for(int j = 0; j < m2.length; j++) {
					//test each piece of both array to see if the currently stored values are equal to each other
					if (m1[i][j] != m2[i][j]) {
						//If at any point two values do not equal, return false
						return false;
					}
				}
			}
			//As long as it runs through the for loops successfully, prints true
			return true;
		}
		//Return false if the two arrays do not equal each other in length
		return false;
	}
	public static void main(String args[]) {
		//Create Scanner
		Scanner input = new Scanner(System.in);
		//For output purposes only
		String iteration = "first";
		//Initialize int Array m1 as 3x3
		int m1 [][] = new int [3][3];
		//Initialize int Array m2 as 3x3
		int m2 [][] = new int [3][3];
		
	// Loop to enter data for first Array
	System.out.println("First two dimensional array:");
	//Sets i to the length of m1
	for(int i = 0; i < m1.length; i++){
		//Sets j to the length of m2
		for (int j = 0; j < m2.length; j++) {
			//For second and third loop to print proper user input in array
			if (j == 1) {
				iteration = "second";
			}
			if (j == 2) {
				iteration = "third";
			}
			//Prompts user with desried input and the location
			System.out.println("Please enter the " + iteration + " number for row: " + (i + 1) + " column: " + (j + 1));
			//Takes in input from user
			int x = input.nextInt();
			//Stores user input into proper place in array
			m1[i][j] = x;
		}
	}
	// Loop to enter data for second Array
	iteration = "first";
	System.out.println("Second two dimensional array:");
	//Sets i to the length of m1
	for(int i = 0; i < m1.length; i++){
		//Sets j to the length of m2
		for (int j = 0; j < m2.length; j++) {
			//For second and third loop to print proper user input in array
			if (j == 1) {
				iteration = "second";
			}
			if (j == 2) {
				iteration = "third";
			}
			//Prompts user with desried input and the location
			System.out.println("Please enter the " + iteration + " number for row: " + (i + 1) + " column: " + (j + 1));
			//Takes in input from user
			int x = input.nextInt();
			//Stores user input into proper place in array
			m2[i][j] = x;
		}
	}
	//If Statement calls the equals function and sends both arrays to it. Returns either true or false to the if statement
	//if true they are identical if false they are not identical
	if (equals(m1, m2)) {
		System.out.println("The two arrays are identical\n");
	}
	else {
		System.out.println("The two arrays are not identical\n");
	}
}
}