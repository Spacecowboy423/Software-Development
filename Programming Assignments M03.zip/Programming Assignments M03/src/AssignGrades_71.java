/*
Project Name: Dream Crusher
Author: Michael Krause
Last Update: 9/23/2021
Purpose: To create a single dimension array and use it to sort the values stored in the array
 */
import java.util.Scanner;

public class AssignGrades_71 {
	//
	//Main Method
	//
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		//Initialize Array with user determined size
		System.out.println("How many students do you have?");
		int i = input.nextInt();
		int Grades [] = new int [i];
		
		//For loop to input students grades, loop is set to run to the array size
		int count;
		for (count = 0; count < i; count++) {
			System.out.println("Please enter the grade for student: " + (count+1));
			int y = input.nextInt();
			Grades[count] = y;
		}
		
		//Find best Grade
		int b = Grades[0];
		int best = 0;
		for (count = 0; count < i; count++) {
			if (b < Grades[count]) {
				b = Grades[count];
				best = count;
			}
		}
		//for loop runs through array to find each grade and print out the scores
		for (count = 0; count < i; count++) {
			//Catch if student got an A
			if (Grades[count] >= (Grades[best] - 10)) {
				System.out.println("Student: " + (count + 1) + " got a score of: " + Grades[count] + " has received an A.");
				continue;
			}
			//Catch if student got a B
			if (Grades[count] >= (Grades[best] - 20)) {
				System.out.println("Student: " + (count + 1) + " got a score of: " + Grades[count] + " has received a B.");
				continue;
			}
			//Catch if student got a C
			if (Grades[count] >= (Grades[best] - 30)) {
				System.out.println("Student: " + (count + 1) + " got a score of: " + Grades[count] + " has received a C.");
				continue;
			}
			//Catch if student got a D
			if (Grades[count] >= (Grades[best] - 40)) {
				System.out.println("Student: " + (count + 1) + " got a score of: " + Grades[count] + " has received a D.");
				continue;
			}
			//Catch if student got an F
			if (Grades[count] < (Grades[best] - 40)) {
				System.out.println("Student: " + (count + 1) + " got a score of: " + Grades[count] + " has received an F.");
				continue;
			}
		}
		
		//Grade A if (score >= (best - 10))
		//Grade B if (score >= (best - 20))
		//Grade C if (score >= (best - 30))
		//Grade D if (score >= (best - 40))
		//Grade F if (otherwise)
		//User enters total number of students
		//Then enters all scores
		//Then display grades
		
		//Display
		//Student 0 score is 40 and grade is C
		//Student 1 score is 55 and grade is B
		//Student 2 score is 70 and grade is A
		
		
		
		
		//new for loop 
		//for (double value: Grades) {
			//System.out.println(value);
		//}
	
	
	}
}
